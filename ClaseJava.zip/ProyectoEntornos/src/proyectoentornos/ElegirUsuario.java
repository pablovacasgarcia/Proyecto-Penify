/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoentornos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pablo
 */
public class ElegirUsuario {
    private String usuario;
    private static final List<String> listaUsuarios = new ArrayList<>();

    static {
        listaUsuarios.add("juan_perez");
        listaUsuarios.add("m.martinez");
        listaUsuarios.add("j.garcia");
        listaUsuarios.add("a_gomez");
        listaUsuarios.add("l-rivera");
        listaUsuarios.add("d-lopez");
        listaUsuarios.add("a-herrera");
        listaUsuarios.add("r_rodriguez");
        listaUsuarios.add("p_fernandez");
        listaUsuarios.add("j.sanchez");
        listaUsuarios.add("m_lozano");
        listaUsuarios.add("c-molina");
        listaUsuarios.add("l-morales");
        listaUsuarios.add("i.soto");
        listaUsuarios.add("e_gonzalez");
        listaUsuarios.add("s_martin");
        listaUsuarios.add("a-santos");
        listaUsuarios.add("j.vargas");
        listaUsuarios.add("m_vila");
        listaUsuarios.add("n_mendez");
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        if (!listaUsuarios.contains(usuario)) {
            this.usuario = usuario;
            System.out.println("Usuario registrado correctamente: " + usuario);
            listaUsuarios.add(usuario);
        } else {
            System.err.println("El usuario ya está en uso: " + usuario);
        }
    }
    
}
