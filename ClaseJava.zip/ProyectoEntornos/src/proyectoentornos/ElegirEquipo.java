/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoentornos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pablo
 */
public class ElegirEquipo {
    private String equipo;
    private static final List<String> listaEquipos = new ArrayList<>();

    static {
        listaEquipos.add("Granada");
        listaEquipos.add("Real Madrid");
        listaEquipos.add("Barcelona");
        listaEquipos.add("Atlético de Madrid");
        listaEquipos.add("Sevilla");
        listaEquipos.add("Real Sociedad");
        listaEquipos.add("Valencia");
        listaEquipos.add("Villarreal");
        listaEquipos.add("Real Betis");
        listaEquipos.add("Athletic Club");
        listaEquipos.add("Celta de Vigo");
        listaEquipos.add("Granada");
        listaEquipos.add("Levante");
        listaEquipos.add("Cadiz");
        listaEquipos.add("Osasuna");
        listaEquipos.add("Getafe");
        listaEquipos.add("Valladolid");
        listaEquipos.add("Elche");
        listaEquipos.add("Alavés");
        listaEquipos.add("Eibar");
        listaEquipos.add("Huesca");
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        if (listaEquipos.contains(equipo)) {
            this.equipo = equipo;
            System.out.println("Equipo seleccionado correctamente: " + equipo);
            listaEquipos.add(equipo);
        } else {
            System.err.println("El equipo no existe o no está disponible: " + equipo);
        }
    }
}
